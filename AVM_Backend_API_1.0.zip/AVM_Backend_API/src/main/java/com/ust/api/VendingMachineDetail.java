package com.ust.api;

public class VendingMachineDetail {

	private long deviceId;
	private long locationId;
	private long posTerminalId;
	private int noOfCoolers;
	private String streetName;
	private String city;
	private String zipCode;
	private String status = "INACTIVE";

	public VendingMachineDetail() {
	}

	@Override
	public String toString() {
		return "VendingMachineDetail [deviceId=" + deviceId + ", locationId=" + locationId + ", posTerminalId="
				+ posTerminalId + ", noOfCoolers=" + noOfCoolers + ", streetName=" + streetName + ", city=" + city
				+ ", zipCode=" + zipCode + ", status=" + status + "]";
	}

	public long getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(long deviceId) {
		this.deviceId = deviceId;
	}

	public long getLocationId() {
		return locationId;
	}

	public void setLocationId(long locationId) {
		this.locationId = locationId;
	}

	public long getPosTerminalId() {
		return posTerminalId;
	}

	public void setPosTerminalId(long posTerminalId) {
		this.posTerminalId = posTerminalId;
	}

	public int getNoOfCoolers() {
		return noOfCoolers;
	}

	public void setNoOfCoolers(int noOfCoolers) {
		this.noOfCoolers = noOfCoolers;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + (int) (deviceId ^ (deviceId >>> 32));
		result = prime * result + (int) (locationId ^ (locationId >>> 32));
		result = prime * result + noOfCoolers;
		result = prime * result + (int) (posTerminalId ^ (posTerminalId >>> 32));
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((streetName == null) ? 0 : streetName.hashCode());
		result = prime * result + ((zipCode == null) ? 0 : zipCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VendingMachineDetail other = (VendingMachineDetail) obj;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (deviceId != other.deviceId)
			return false;
		if (locationId != other.locationId)
			return false;
		if (noOfCoolers != other.noOfCoolers)
			return false;
		if (posTerminalId != other.posTerminalId)
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (streetName == null) {
			if (other.streetName != null)
				return false;
		} else if (!streetName.equals(other.streetName))
			return false;
		if (zipCode == null) {
			if (other.zipCode != null)
				return false;
		} else if (!zipCode.equals(other.zipCode))
			return false;
		return true;
	}

}
