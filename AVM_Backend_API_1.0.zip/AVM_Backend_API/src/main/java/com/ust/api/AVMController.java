package com.ust.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin()
public class AVMController {

	public static List<Product> productList = new ArrayList<>();
	public static Map<String, Product> barCodeToProductMap = new HashMap<>();
	private static CartData cartData = null;
	private int totalCabinetCount = 1;
	private boolean isCartCheckout = false;
	private int selectedCabinet = -1;
	private boolean isJourneyStarted = false;

	@GetMapping("/loadproduct")
	public String loadProductList() {

		ControllerUtil.readProductDetail(productList, barCodeToProductMap);
		return "Product List Loaded";
	}

	@GetMapping("/getjourneystatus")
	public boolean getUserJourneyStatus() {

		return isJourneyStarted;
	}

	@GetMapping("/setjourneystatus")
	public void setUserJourneyStatus(boolean journey) {

		this.isJourneyStarted = journey;
	}

	@GetMapping("/getproductlist")
	public List<Product> getProdcutList() {
		System.out.println("Request for Product List: " + productList.size());
		return productList;
	}

	@GetMapping("/getcheckout")
	public boolean getCartCheckout() {

		return isCartCheckout;
	}

	@GetMapping("/setcheckout")
	public void setCartCheckout(boolean checkout) {

		this.isCartCheckout = checkout;

	}

	@GetMapping("/getcabinetcount")
	public int getCabinetCount() {

		return totalCabinetCount;
	}

	@GetMapping("/setcabinetcount")
	public void setCabinetCount(int count) {

		this.totalCabinetCount = count;
	}

	@GetMapping("/setcabinetselected")
	public void setCabinetSelected(int cabinet) {

		System.out.println("Frontend Requested to Set Cabinet Selected as : " + cabinet);
		this.selectedCabinet = cabinet;

		if (cabinet > 0) {

			HardwareCall.openCabinet(cabinet);
		}

	}

	@GetMapping("/getcabinetselected")
	public int getCabinetSelected() {

		return selectedCabinet;
	}

	@GetMapping("/resetcart")
	public String resetUserCart() {
		cartData = new CartData();
		return "Cart Reset of User - Guest";
	}

	@GetMapping("/getcart")
	public String getUserCart() {

		if (cartData == null)
			return "{}";
		else
			return cartData.formatterCartData();
	}

	@GetMapping("/updatecart")
	public String updateUserCart(String barcode, int quantity) {

		if (cartData == null)
			cartData = new CartData();

		performProductUpdateOnCart(barcode, quantity);

		return "Cart List Updated for Barcode: " + barcode;
	}

	@PostMapping("/updatecart")
	public String updateUserCartJSON(@RequestBody HWProductResponse hwProductResponse) {

		if (cartData == null)
			cartData = new CartData();

//		System.out.println("Current Cart Data = "+cartData.toString());
//		System.out.println("barcode = "+barcode);
//		System.out.println("barCodeToProductMap = "+ barCodeToProductMap.toString());

		System.out.println("hwProductResponse = " + hwProductResponse.toString());
		ArrayList<ProductHW> cv_response = hwProductResponse.getCv_response();

		for (ProductHW productHW : cv_response) {

			performProductUpdateOnCart("" + productHW.getBarcode(), productHW.getQuantity());
		}

		return "Cart List Updated";
	}

	private void performProductUpdateOnCart(String barcode, int quantity) {

		Product productToAddOrUpdate = barCodeToProductMap.get(barcode.trim());

		List<ProductData> productDataList = cartData.getProductDataList();

		boolean isQunatityUpdatedInExistingCart = false;

		for (ProductData productData : productDataList) {

			String barCodeInExistingCart = productData.getProduct().getBarcode();

			if (barCodeInExistingCart.equalsIgnoreCase(barcode.trim())) {

				productData.setQuantity(productData.getQuantity() + quantity);
				productData.setProductTotalCost(Double.parseDouble(
						String.format("%.2f", (productData.getQuantity() * productData.getProduct().getPrice()))));
				isQunatityUpdatedInExistingCart = true;
				break;
			}
		}

		productDataList.removeIf(productData -> productData.getQuantity() <= 0);

		if (!isQunatityUpdatedInExistingCart) {

			ProductData productData = new ProductData(productToAddOrUpdate, 1, productToAddOrUpdate.getPrice() * 1);
			productDataList.add(productData);
			cartData.setProductDataList(productDataList);
		}

		int cartTotalQuantity = 0;
		double cartTotalCost = 0;

		for (ProductData productData : cartData.getProductDataList()) {

			cartTotalQuantity = cartTotalQuantity + productData.getQuantity();
			cartTotalCost = Double
					.parseDouble(String.format("%.2f", (cartTotalCost + productData.getProductTotalCost())));
		}

		cartData.setTotalCartPrice(cartTotalCost);
		cartData.setTotalCartQuantity(cartTotalQuantity);

	}

}
