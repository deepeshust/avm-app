package com.ust.api;

public class ProductHW {

	private int barcode;
	private int quantity;
	
	
	public ProductHW() {
	}


	public ProductHW(int barcode, int quantity) {
		super();
		this.barcode = barcode;
		this.quantity = quantity;
	}


	public int getBarcode() {
		return barcode;
	}


	public void setBarcode(int barcode) {
		this.barcode = barcode;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + barcode;
		result = prime * result + quantity;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductHW other = (ProductHW) obj;
		if (barcode != other.barcode)
			return false;
		if (quantity != other.quantity)
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "ProductReceived [barcode=" + barcode + ", quantity=" + quantity + "]";
	}
	
	
	
}
