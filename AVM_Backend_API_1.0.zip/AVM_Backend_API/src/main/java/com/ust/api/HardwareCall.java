package com.ust.api;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.time.Instant;

public class HardwareCall {

	private static long session = 0;
	
	static {
		session = Instant.now().toEpochMilli();
	}
	public static void openCabinet(int cabinet) {
		
		try {
			System.out.println("Requesting Hardware Component to Open Cabinet No.: "+cabinet);
			
			Socket socket = new Socket("127.0.0.1", 8082);
			DataOutputStream dout = new DataOutputStream(socket.getOutputStream());
			String sendJson = "{\"session_id\":"+session+",\"action_id\": 2, \"cabinets\": ["+cabinet+"]}";
			//dout.writeUTF(sendJson);
			dout.write(sendJson.getBytes());

			BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			String readResponse = reader.readLine();
			System.out.println("Hardware Responded with Message: " + readResponse);
			
			Thread.sleep(1000);
//			
//			dout = new DataOutputStream(socket.getOutputStream());			
//			dout.writeUTF("{action_id: 102, action_data: [2]}");
//			reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//			readResponse = reader.readLine();
//			System.out.println("readResponse = " + readResponse);
//			
			
		
			//	}
//			dout.flush();
//			dout.close();
			// s.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
