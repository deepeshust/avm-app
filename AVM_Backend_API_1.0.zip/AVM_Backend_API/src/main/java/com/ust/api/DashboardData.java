package com.ust.api;

import java.util.HashMap;
import java.util.Map;

public class DashboardData {

	private String bestLocation = "Houston";
	private String worstLocation = "Chicago";
	private String bestProduct = "Coca-Cola 300 ml";
	private String powerConsumptions = "500 kWh";
	private String totalRevenue = "$10,000,000";
	private Map<String, Double> locationRevenueMap = new HashMap<>();

	public DashboardData() {

		locationRevenueMap.put("Los Angeles", 100.0);
		locationRevenueMap.put("Chicago", 200.0);
		locationRevenueMap.put("Houston", 400.0);
		locationRevenueMap.put("Las Vegas", 250.0);
		locationRevenueMap.put("Boston", 180.0);
		locationRevenueMap.put("Washington", 550.0);
	}

	public String getBestLocation() {
		return bestLocation;
	}

	public void setBestLocation(String bestLocation) {
		this.bestLocation = bestLocation;
	}

	public String getWorstLocation() {
		return worstLocation;
	}

	public void setWorstLocation(String worstLocation) {
		this.worstLocation = worstLocation;
	}

	public String getBestProduct() {
		return bestProduct;
	}

	public void setBestProduct(String bestProduct) {
		this.bestProduct = bestProduct;
	}

	public String getPowerConsumptions() {
		return powerConsumptions;
	}

	public void setPowerConsumptions(String powerConsumptions) {
		this.powerConsumptions = powerConsumptions;
	}

	public String getTotalRevenue() {
		return totalRevenue;
	}

	public void setTotalRevenue(String totalRevenue) {
		this.totalRevenue = totalRevenue;
	}

	public Map<String, Double> getLocationRevenueMap() {
		return locationRevenueMap;
	}

	public void setLocationRevenueMap(Map<String, Double> locationRevenueMap) {
		this.locationRevenueMap = locationRevenueMap;
	}

	@Override
	public String toString() {
		return "DashboardData [bestLocation=" + bestLocation + ", worstLocation=" + worstLocation + ", bestProduct="
				+ bestProduct + ", powerConsumptions=" + powerConsumptions + ", totalRevenue=" + totalRevenue
				+ ", locationRevenueMap=" + locationRevenueMap + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bestLocation == null) ? 0 : bestLocation.hashCode());
		result = prime * result + ((bestProduct == null) ? 0 : bestProduct.hashCode());
		result = prime * result + ((locationRevenueMap == null) ? 0 : locationRevenueMap.hashCode());
		result = prime * result + ((powerConsumptions == null) ? 0 : powerConsumptions.hashCode());
		result = prime * result + ((totalRevenue == null) ? 0 : totalRevenue.hashCode());
		result = prime * result + ((worstLocation == null) ? 0 : worstLocation.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DashboardData other = (DashboardData) obj;
		if (bestLocation == null) {
			if (other.bestLocation != null)
				return false;
		} else if (!bestLocation.equals(other.bestLocation))
			return false;
		if (bestProduct == null) {
			if (other.bestProduct != null)
				return false;
		} else if (!bestProduct.equals(other.bestProduct))
			return false;
		if (locationRevenueMap == null) {
			if (other.locationRevenueMap != null)
				return false;
		} else if (!locationRevenueMap.equals(other.locationRevenueMap))
			return false;
		if (powerConsumptions == null) {
			if (other.powerConsumptions != null)
				return false;
		} else if (!powerConsumptions.equals(other.powerConsumptions))
			return false;
		if (totalRevenue == null) {
			if (other.totalRevenue != null)
				return false;
		} else if (!totalRevenue.equals(other.totalRevenue))
			return false;
		if (worstLocation == null) {
			if (other.worstLocation != null)
				return false;
		} else if (!worstLocation.equals(other.worstLocation))
			return false;
		return true;
	}

}
