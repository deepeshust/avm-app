package com.ust.api;

import java.util.ArrayList;
import java.util.List;

public class CartData {

	private List<ProductData> productDataList = new ArrayList<>();
	private int totalCartQuantity;
	private double totalCartPrice;
	private String user = "Guest";

	public CartData() {

	}

	public String formatterCartData() {

		StringBuilder sb = new StringBuilder();

		sb.append("{").append("\"productDataList\":[");

		for (int i = 0; i < productDataList.size(); i++) {

			ProductData pd = productDataList.get(i);
			Product product = pd.getProduct();
			sb.append("{\"product\":").append("{\"barcode\":\"").append(product.getBarcode()).append("\"");
			sb.append(",").append("\"name\":\"").append(product.getName()).append("\"");
			sb.append(",").append("\"price\":\"$ ").append(product.getPrice()).append("\"");
			sb.append(",").append("\"imageURL\":\"").append(product.getImageURL()).append("\"");;
			sb.append("},");
			sb.append("\"quantity\":").append(pd.getQuantity()).append(",");
			sb.append("\"productTotalCost\":\"$ ").append(pd.getProductTotalCost()).append("\"");
			sb.append("}");

			if (i == productDataList.size() - 1) {
				sb.append("]");
			} else {
				sb.append(",");
			}
		}
		sb.append(",\"totalCartQuantity\":").append(totalCartQuantity);
		sb.append(",\"totalCartPrice\":\"$ ").append(totalCartPrice).append("\"");
		sb.append(",\"user\":").append("\"Guest\"");
		sb.append("}");

		return sb.toString();
	}

	public CartData(List<ProductData> productDataList, int totalCartQuantity, double totalCartPrice, String user) {

		this.productDataList = productDataList;
		this.totalCartQuantity = totalCartQuantity;
		this.totalCartPrice = totalCartPrice;
		this.user = user;
	}

	public List<ProductData> getProductDataList() {
		return productDataList;
	}

	public void setProductDataList(List<ProductData> productDataList) {
		this.productDataList = productDataList;
	}

	public int getTotalCartQuantity() {
		return totalCartQuantity;
	}

	public void setTotalCartQuantity(int totalCartQuantity) {
		this.totalCartQuantity = totalCartQuantity;
	}

	public double getTotalCartPrice() {
		return totalCartPrice;
	}

	public void setTotalCartPrice(double totalCartPrice) {
		this.totalCartPrice = totalCartPrice;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "CartData [productDataList=" + productDataList + ", totalCartQuantity=" + totalCartQuantity
				+ ", totalCartPrice=" + totalCartPrice + ", user=" + user + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((productDataList == null) ? 0 : productDataList.hashCode());
		long temp;
		temp = Double.doubleToLongBits(totalCartPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + totalCartQuantity;
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CartData other = (CartData) obj;
		if (productDataList == null) {
			if (other.productDataList != null)
				return false;
		} else if (!productDataList.equals(other.productDataList))
			return false;
		if (Double.doubleToLongBits(totalCartPrice) != Double.doubleToLongBits(other.totalCartPrice))
			return false;
		if (totalCartQuantity != other.totalCartQuantity)
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}

}