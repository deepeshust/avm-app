package com.ust.api;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class VMData {

	private final List<String> vmDeviceHeader = new ArrayList<>(Arrays.asList("Device ID", "Location ID",
			"POS Terminal ID", "No of Coolers", "Street Name", "City", "Zip Code", "Status", "Action"));

	private List<VendingMachineDetail> vmDeviceList = new ArrayList<>();

	public List<VendingMachineDetail> getVmDeviceList() {
		return vmDeviceList;
	}

	public void setVmDeviceList(List<VendingMachineDetail> vmDeviceList) {
		this.vmDeviceList = vmDeviceList;
	}

	public List<String> getVmDeviceHeader() {
		return vmDeviceHeader;
	}

	@Override
	public String toString() {
		return "VMData [vmDeviceHeader=" + vmDeviceHeader + ", vmDeviceList=" + vmDeviceList.toString() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((vmDeviceHeader == null) ? 0 : vmDeviceHeader.hashCode());
		result = prime * result + ((vmDeviceList == null) ? 0 : vmDeviceList.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VMData other = (VMData) obj;
		if (vmDeviceHeader == null) {
			if (other.vmDeviceHeader != null)
				return false;
		} else if (!vmDeviceHeader.equals(other.vmDeviceHeader))
			return false;
		if (vmDeviceList == null) {
			if (other.vmDeviceList != null)
				return false;
		} else if (!vmDeviceList.equals(other.vmDeviceList))
			return false;
		return true;
	}

}
