package com.ust.api;

public class ProductCatalogue {

	private String skuId;
	private String productName;
	private String productImage;
	private String brandName;
	private String productCategory;
	private double productCost;
	private double productSellingPrice;
	private double productWeight;
	private double productHeight;
	private double productLength;
	private double productWidth;
	private String productExpiry;
	private String productSupplierDetail;
	private String productManufacturerDetail;
	private int productTotalInventoryQty;
	private int productLowInventoryQty;
	private String productOrderDate;
	private String productTaxCategory;
	private String productTaxPercentage;
	private double productCalories;
	private double productFat;
	private double productProtien;
	private double productEnergy;
	private String productIngredients;
	private String productAllergyDetails;

	public ProductCatalogue() {

	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public double getProductCost() {
		return productCost;
	}

	public void setProductCost(double productCost) {
		this.productCost = productCost;
	}

	public double getProductSellingPrice() {
		return productSellingPrice;
	}

	public void setProductSellingPrice(double productSellingPrice) {
		this.productSellingPrice = productSellingPrice;
	}

	public double getProductWeight() {
		return productWeight;
	}

	public void setProductWeight(double productWeight) {
		this.productWeight = productWeight;
	}

	public double getProductHeight() {
		return productHeight;
	}

	public void setProductHeight(double productHeight) {
		this.productHeight = productHeight;
	}

	public double getProductLength() {
		return productLength;
	}

	public void setProductLength(double productLength) {
		this.productLength = productLength;
	}

	public double getProductWidth() {
		return productWidth;
	}

	public void setProductWidth(double productWidth) {
		this.productWidth = productWidth;
	}

	public String getProductExpiry() {
		return productExpiry;
	}

	public void setProductExpiry(String productExpiry) {
		this.productExpiry = productExpiry;
	}

	public String getProductSupplierDetail() {
		return productSupplierDetail;
	}

	public void setProductSupplierDetail(String productSupplierDetail) {
		this.productSupplierDetail = productSupplierDetail;
	}

	public String getProductManufacturerDetail() {
		return productManufacturerDetail;
	}

	public void setProductManufacturerDetail(String productManufacturerDetail) {
		this.productManufacturerDetail = productManufacturerDetail;
	}

	public int getProductTotalInventoryQty() {
		return productTotalInventoryQty;
	}

	public void setProductTotalInventoryQty(int productTotalInventoryQty) {
		this.productTotalInventoryQty = productTotalInventoryQty;
	}

	public int getProductLowInventoryQty() {
		return productLowInventoryQty;
	}

	public void setProductLowInventoryQty(int productLowInventoryQty) {
		this.productLowInventoryQty = productLowInventoryQty;
	}

	public String getProductOrderDate() {
		return productOrderDate;
	}

	public void setProductOrderDate(String productOrderDate) {
		this.productOrderDate = productOrderDate;
	}

	public String getProductTaxCategory() {
		return productTaxCategory;
	}

	public void setProductTaxCategory(String productTaxCategory) {
		this.productTaxCategory = productTaxCategory;
	}

	public String getProductTaxPercentage() {
		return productTaxPercentage;
	}

	public void setProductTaxPercentage(String productTaxPercentage) {
		this.productTaxPercentage = productTaxPercentage;
	}

	public double getProductCalories() {
		return productCalories;
	}

	public void setProductCalories(double productCalories) {
		this.productCalories = productCalories;
	}

	public double getProductFat() {
		return productFat;
	}

	public void setProductFat(double productFat) {
		this.productFat = productFat;
	}

	public double getProductProtien() {
		return productProtien;
	}

	public void setProductProtien(double productProtien) {
		this.productProtien = productProtien;
	}

	public double getProductEnergy() {
		return productEnergy;
	}

	public void setProductEnergy(double productEnergy) {
		this.productEnergy = productEnergy;
	}

	public String getProductIngredients() {
		return productIngredients;
	}

	public void setProductIngredients(String productIngredients) {
		this.productIngredients = productIngredients;
	}

	public String getProductAllergyDetails() {
		return productAllergyDetails;
	}

	public void setProductAllergyDetails(String productAllergyDetails) {
		this.productAllergyDetails = productAllergyDetails;
	}

	@Override
	public String toString() {
		return "ProductCatalogue [skuId=" + skuId + ", productName=" + productName + ", productImage=" + productImage
				+ ", brandName=" + brandName + ", productCategory=" + productCategory + ", productCost=" + productCost
				+ ", productSellingPrice=" + productSellingPrice + ", productWeight=" + productWeight
				+ ", productHeight=" + productHeight + ", productLength=" + productLength + ", productWidth="
				+ productWidth + ", productExpiry=" + productExpiry + ", productSupplierDetail=" + productSupplierDetail
				+ ", productManufacturerDetail=" + productManufacturerDetail + ", productTotalInventoryQty="
				+ productTotalInventoryQty + ", productLowInventoryQty=" + productLowInventoryQty
				+ ", productOrderDate=" + productOrderDate + ", productTaxCategory=" + productTaxCategory
				+ ", productTaxPercentage=" + productTaxPercentage + ", productCalories=" + productCalories
				+ ", productFat=" + productFat + ", productProtien=" + productProtien + ", productEnergy="
				+ productEnergy + ", productIngredients=" + productIngredients + ", productAllergyDetails="
				+ productAllergyDetails + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((brandName == null) ? 0 : brandName.hashCode());
		result = prime * result + ((productAllergyDetails == null) ? 0 : productAllergyDetails.hashCode());
		long temp;
		temp = Double.doubleToLongBits(productCalories);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((productCategory == null) ? 0 : productCategory.hashCode());
		temp = Double.doubleToLongBits(productCost);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(productEnergy);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((productExpiry == null) ? 0 : productExpiry.hashCode());
		temp = Double.doubleToLongBits(productFat);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(productHeight);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((productImage == null) ? 0 : productImage.hashCode());
		result = prime * result + ((productIngredients == null) ? 0 : productIngredients.hashCode());
		temp = Double.doubleToLongBits(productLength);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + productLowInventoryQty;
		result = prime * result + ((productManufacturerDetail == null) ? 0 : productManufacturerDetail.hashCode());
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + ((productOrderDate == null) ? 0 : productOrderDate.hashCode());
		temp = Double.doubleToLongBits(productProtien);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(productSellingPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((productSupplierDetail == null) ? 0 : productSupplierDetail.hashCode());
		result = prime * result + ((productTaxCategory == null) ? 0 : productTaxCategory.hashCode());
		result = prime * result + ((productTaxPercentage == null) ? 0 : productTaxPercentage.hashCode());
		result = prime * result + productTotalInventoryQty;
		temp = Double.doubleToLongBits(productWeight);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(productWidth);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((skuId == null) ? 0 : skuId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductCatalogue other = (ProductCatalogue) obj;
		if (brandName == null) {
			if (other.brandName != null)
				return false;
		} else if (!brandName.equals(other.brandName))
			return false;
		if (productAllergyDetails == null) {
			if (other.productAllergyDetails != null)
				return false;
		} else if (!productAllergyDetails.equals(other.productAllergyDetails))
			return false;
		if (Double.doubleToLongBits(productCalories) != Double.doubleToLongBits(other.productCalories))
			return false;
		if (productCategory == null) {
			if (other.productCategory != null)
				return false;
		} else if (!productCategory.equals(other.productCategory))
			return false;
		if (Double.doubleToLongBits(productCost) != Double.doubleToLongBits(other.productCost))
			return false;
		if (Double.doubleToLongBits(productEnergy) != Double.doubleToLongBits(other.productEnergy))
			return false;
		if (productExpiry == null) {
			if (other.productExpiry != null)
				return false;
		} else if (!productExpiry.equals(other.productExpiry))
			return false;
		if (Double.doubleToLongBits(productFat) != Double.doubleToLongBits(other.productFat))
			return false;
		if (Double.doubleToLongBits(productHeight) != Double.doubleToLongBits(other.productHeight))
			return false;
		if (productImage == null) {
			if (other.productImage != null)
				return false;
		} else if (!productImage.equals(other.productImage))
			return false;
		if (productIngredients == null) {
			if (other.productIngredients != null)
				return false;
		} else if (!productIngredients.equals(other.productIngredients))
			return false;
		if (Double.doubleToLongBits(productLength) != Double.doubleToLongBits(other.productLength))
			return false;
		if (productLowInventoryQty != other.productLowInventoryQty)
			return false;
		if (productManufacturerDetail == null) {
			if (other.productManufacturerDetail != null)
				return false;
		} else if (!productManufacturerDetail.equals(other.productManufacturerDetail))
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (productOrderDate == null) {
			if (other.productOrderDate != null)
				return false;
		} else if (!productOrderDate.equals(other.productOrderDate))
			return false;
		if (Double.doubleToLongBits(productProtien) != Double.doubleToLongBits(other.productProtien))
			return false;
		if (Double.doubleToLongBits(productSellingPrice) != Double.doubleToLongBits(other.productSellingPrice))
			return false;
		if (productSupplierDetail == null) {
			if (other.productSupplierDetail != null)
				return false;
		} else if (!productSupplierDetail.equals(other.productSupplierDetail))
			return false;
		if (productTaxCategory == null) {
			if (other.productTaxCategory != null)
				return false;
		} else if (!productTaxCategory.equals(other.productTaxCategory))
			return false;
		if (productTaxPercentage == null) {
			if (other.productTaxPercentage != null)
				return false;
		} else if (!productTaxPercentage.equals(other.productTaxPercentage))
			return false;
		if (productTotalInventoryQty != other.productTotalInventoryQty)
			return false;
		if (Double.doubleToLongBits(productWeight) != Double.doubleToLongBits(other.productWeight))
			return false;
		if (Double.doubleToLongBits(productWidth) != Double.doubleToLongBits(other.productWidth))
			return false;
		if (skuId == null) {
			if (other.skuId != null)
				return false;
		} else if (!skuId.equals(other.skuId))
			return false;
		return true;
	}

}
