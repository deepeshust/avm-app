package com.ust.api;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class ControllerUtil {

	public static void readProductDetail(List<Product> productList, Map<String, Product> barCodeToProductMap) {

		try {
			// productList = new ArrayList<>();
			// barCodeToProductMap = new HashMap<>();

			String gitURL = "https://raw.githubusercontent.com/deepeshust/avm/main/sample-product";

			StringBuilder content = new StringBuilder();

			URL url = new URL(gitURL); // creating a url object
			URLConnection urlConnection = url.openConnection(); // creating a urlconnection object
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
			String line;
			while ((line = bufferedReader.readLine()) != null) {

				content.append(line + "\n");
			}
			bufferedReader.close();

			 System.out.println(content.toString());

			List<String> productLineList = new ArrayList<>(Arrays.asList(content.toString().split("\n")));
			productLineList.remove(0);
			// System.out.println(productLineList);

			for (String eachLine : productLineList) {

				if (eachLine == null || eachLine.trim().isEmpty())
					continue;
				String[] data = eachLine.split(",");

				Product pd = new Product(data[0], data[1], Double.parseDouble(data[2].trim()), data[3]);

				productList.add(pd);
				barCodeToProductMap.put(pd.getBarcode(), pd);
			}

			// productList.forEach(pd -> System.out.println(pd.toString()));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
