package com.ust.api;

import java.util.ArrayList;

public class HWProductResponse {

	private int session_id;
	private ArrayList<ProductHW> sbw_response;
	private ArrayList<ProductHW> cv_response;
	private String timestamp;

	public HWProductResponse() {
	}

	public HWProductResponse(int session_id, ArrayList<ProductHW> sbw_response,
			ArrayList<ProductHW> cv_response, String timestamp) {
		super();
		this.session_id = session_id;
		this.sbw_response = sbw_response;
		this.cv_response = cv_response;
		this.timestamp = timestamp;
	}

	public int getSession_id() {
		return session_id;
	}

	public void setSession_id(int session_id) {
		this.session_id = session_id;
	}

	public ArrayList<ProductHW> getSbw_response() {
		return sbw_response;
	}

	public void setSbw_response(ArrayList<ProductHW> sbw_response) {
		this.sbw_response = sbw_response;
	}

	public ArrayList<ProductHW> getCv_response() {
		return cv_response;
	}

	public void setCv_response(ArrayList<ProductHW> cv_response) {
		this.cv_response = cv_response;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cv_response == null) ? 0 : cv_response.hashCode());
		result = prime * result + ((sbw_response == null) ? 0 : sbw_response.hashCode());
		result = prime * result + session_id;
		result = prime * result + ((timestamp == null) ? 0 : timestamp.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HWProductResponse other = (HWProductResponse) obj;
		if (cv_response == null) {
			if (other.cv_response != null)
				return false;
		} else if (!cv_response.equals(other.cv_response))
			return false;
		if (sbw_response == null) {
			if (other.sbw_response != null)
				return false;
		} else if (!sbw_response.equals(other.sbw_response))
			return false;
		if (session_id != other.session_id)
			return false;
		if (timestamp == null) {
			if (other.timestamp != null)
				return false;
		} else if (!timestamp.equals(other.timestamp))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "HWProductResponse [session_id=" + session_id + ", sbw_response=" + sbw_response + ", cv_response="
				+ cv_response + ", timestamp=" + timestamp + "]";
	}

}
