package com.ust.api;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin()
@RestController
public class WebAppController {

	VMData vmData = new VMData();

	private List<String> searchStatusList = new ArrayList<>(
			Arrays.asList("ALL", "ACTIVE", "INACTIVE", "TERMINATED", "ONHOLD"));

	private List<String> deviceStatusList = new ArrayList<>(
			Arrays.asList("ACTIVE", "INACTIVE", "TERMINATED", "ONHOLD"));

	@GetMapping("/sm/vmdata/raw")
	public VendingMachineDetail vendingMachineRaw() {

		return new VendingMachineDetail();
	}

	@GetMapping("/sm/vmdata/searchstatuslist")
	public List<String> searchStatusList() {

		return searchStatusList;
	}

	@GetMapping("/sm/vmdata/devicestatuslist")
	public List<String> deviceStatusList() {

		return deviceStatusList;
	}

	@GetMapping("/sm/vmdata/dashboard")
	public DashboardData getDashboard() {

		return new DashboardData();
	}

	@GetMapping("/sm/vmdata/devicelist")
	public VMData vendingMachineListAsPerStatus(@RequestParam String status, @RequestParam String city) {

		List<VendingMachineDetail> filteredList = null;

		if (status == null || status.trim().isEmpty() || status.trim().equalsIgnoreCase("ALL")) {

			filteredList = vmData.getVmDeviceList();

		} else {

			filteredList = vmData.getVmDeviceList().stream()
					.filter(vm -> vm.getStatus().trim().equalsIgnoreCase(status.trim())).collect(Collectors.toList());
		}

		if (city != null && !city.trim().isEmpty() && !city.trim().equalsIgnoreCase("null")) {

			filteredList = filteredList.stream().filter(vm -> (vm.getCity() != null
					&& vm.getCity().toLowerCase().contains(city.trim().toLowerCase()))
					|| (vm.getZipCode() != null && vm.getZipCode().toLowerCase().contains(city.trim().toLowerCase())))
					.collect(Collectors.toList());
		}

		VMData tmpVMData = new VMData();
		tmpVMData.setVmDeviceList(filteredList);
		
		return tmpVMData;

	}

	@PostMapping("/sm/vmdata")
	public String vendingMachineAdd(@RequestBody VendingMachineDetail vendingMachineDetail) {

		List<Long> deviceIdList = vmData.getVmDeviceList().stream().map(vm -> vm.getDeviceId())
				.collect(Collectors.toList());

		if (deviceIdList.contains(vendingMachineDetail.getDeviceId())) {

			return vendingMachineDetail.getDeviceId()
					+ " Already Exists! - try put method to update values against device id";
		} else {
			vmData.getVmDeviceList().add(vendingMachineDetail);
			return vendingMachineDetail.getDeviceId() + " Added Successfully!";

		}

	}

	@PutMapping("/sm/vmdata")
	public String vendingMachineUpdate(@RequestBody VendingMachineDetail vendingMachineDetail) {

		long vmId = vendingMachineDetail.getDeviceId();
		Iterator<VendingMachineDetail> it = vmData.getVmDeviceList().iterator();
		boolean isUpdated = false;
		while (it.hasNext()) {

			VendingMachineDetail vm = it.next();
			if (vm.getDeviceId() == vmId) {
				it.remove();
				isUpdated = true;
				vmData.getVmDeviceList().add(vendingMachineDetail);
				break;
			}
		}

		return isUpdated ? "Device Data Updated for Device Id:" + vmId : " Device Not Found for Device Id: " + vmId;
	}

	@DeleteMapping("/sm/vmdata/{vmId}")
	public String vendingMachineDelete(@PathVariable Long vmId) {

		// System.out.println("vmId = " + vmId);
		Iterator<VendingMachineDetail> it = vmData.getVmDeviceList().iterator();
		boolean isDeleted = false;
		while (it.hasNext()) {

			VendingMachineDetail vm = it.next();
			if (vm.getDeviceId() == vmId) {
				it.remove();
				isDeleted = true;
				break;
			}
		}

		return "VM Id: " + vmId + (isDeleted ? " Deleted Successfully!" : " Not Foud!");

	}

	@GetMapping("/sm/catalogue")
	public List<ProductCatalogue> getProductCatalogue() {

		List<ProductCatalogue> list = new ArrayList<>();
		list.add(new ProductCatalogue());
		// ControllerUtil.readProductDetail(productList, barCodeToProductMap);
		return list;
	}
	//
}
